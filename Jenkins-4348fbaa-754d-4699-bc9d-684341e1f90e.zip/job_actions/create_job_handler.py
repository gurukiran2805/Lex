# job_actions/create_job_handler.py
from utils.jenkins_connection import create_job
from utils.response_utils import generate_response, error_response, get_default_buttons

def create_job_handler(event):
    """
    Handles the 'Create Job' intent.
    """
    slots = event['sessionState']['intent']['slots']
    intent = event['sessionState']['intent']['name']
    
    jobname = slots['JobName']['value']['originalValue']
    job_type = slots['JobType']['value']['originalValue']
    github_url = slots.get('GitHubURL', {}).get('value', {}).get('originalValue', '')

    try:
        result = create_job(jobname, job_type, github_url)
        message = (
            f"🎉 **Success!** You've successfully created the **{job_type}** job: '{jobname}'.\n\n"
            f"👉 You can now start building this job or manage it further.\n\n"
            f"🔗 [Access the job here]({JENKINS_Url}job/{jobname})."
        )
        return generate_response(
            intent,
            slots,
            message,
            buttons=get_default_buttons(),
            state='Fulfilled'
        )
    except Exception as e:
        return error_response(
            intent,
            slots,
            f"❌ **Oops! Something went wrong** while creating the job.\n\n"
            f"Error: {str(e)}. Please check the job type or GitHub URL and try again."
        )
