from job_actions.create_job_handler import create_job_handler
from job_actions.build_job_handler import build_job_handler
from job_actions.delete_job_handler import delete_job_handler
from job_actions.rename_job_handler import rename_job_handler
from job_actions.greet_job_handler import greet_job_handler  
from utils.response_utils import error_response
from utils.fallback import fallback_handler

def lambda_handler(event, context):
   
    print(f"Received event: {event}")
    
    intents = event['sessionState']['intent']['name']
    
    if intents == 'CreateJobIntent':
        return create_job_handler(event)
    elif intents == 'BuildJobIntent':
        return build_job_handler(event)
    elif intents == 'DeleteJobIntent':
        return delete_job_handler(event)
    elif intents == 'RenameJobIntent':  
        return rename_job_handler(event)
    elif intents == 'GreetJobIntent':  
        return greet_job_handler(event)
    elif intents == 'FallbackIntent':
        return fallback_handler(event)
    else:
        # Handle unexpected intents or errors gracefully
        error_message = "Unrecognized intent detected."  # Define the error message
        return error_response(
            intent=intents,
            slots={},  # Pass an empty dictionary if no slots are required
            error_message=error_message  # Pass the error message
        )
