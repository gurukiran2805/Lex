# utils/jenkins_connection.py
import jenkins

USER = 'admin'
API = '118d0b22734270be03adb20c492479f7c2'
JENKINS_Url = "http://54.167.67.231:8080/"
server = jenkins.Jenkins(JENKINS_Url, username=USER, password=API)

def create_job(jobname, job_type, github_url=""):
    """
    Creates a job in Jenkins based on job type.
    """
    if job_type == 'Freestyle':
        server.create_job(jobname, jenkins.EMPTY_CONFIG_XML)
    elif job_type == 'Pipeline':
        config_xml = """<flow-definition>
            <definition class="org.jenkinsci.plugins.workflow.cps.CpsFlowDefinition">
                <script>node { ... }</script>
            </definition>
        </flow-definition>"""
        server.create_job(jobname, config_xml)
    elif job_type == 'MultibranchPipeline' and github_url:
        config_xml = f"""<flow-definition>
            <definition class="org.jenkinsci.plugins.workflow.multibranch.WorkflowMultiBranchProject">
                <sources>
                    <jenkins.branch.GitHubSCMSource>
                        <repoOwner>my-repo-owner</repoOwner>
                        <repository>{github_url}</repository>
                    </jenkins.branch.GitHubSCMSource>
                </sources>
            </definition>
        </flow-definition>"""
        server.create_job(jobname, config_xml)
    else:
        raise ValueError("Unsupported job type or missing GitHub URL")

def build_job(jobname):
    """
    Triggers a build for the specified Jenkins job.
    """
    if server.job_exists(jobname):
        return server.build_job(jobname)
    else:
        raise ValueError(f"Job '{jobname}' does not exist.")

def delete_job(jobname):
    """
    Deletes the specified Jenkins job.
    """
    if server.job_exists(jobname):
        server.delete_job(jobname)
    else:
        raise ValueError(f"Job '{jobname}' does not exist.")

def rename_job(old_jobname, new_jobname):
    """
    Renames a Jenkins job from old_jobname to new_jobname.
    """
    if server.job_exists(old_jobname):
        # Create a new job with the new name
        job_config = server.get_job_config(old_jobname)
        server.create_job(new_jobname, job_config)
        
        # Now delete the old job
        server.delete_job(old_jobname)
        return True
    else:
        raise ValueError(f"Job '{old_jobname}' does not exist.")
