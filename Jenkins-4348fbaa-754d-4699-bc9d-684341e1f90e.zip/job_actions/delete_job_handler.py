# job_actions/delete_job_handler.py
from utils.jenkins_connection import delete_job
from utils.response_utils import generate_response, error_response, get_default_buttons

def delete_job_handler(event):
    """
    Handles the 'Delete Job' intent.
    """
    slots = event['sessionState']['intent']['slots']
    intent = event['sessionState']['intent']['name']
    jobname = slots['JobName']['value']['originalValue']
    
    try:
        result = delete_job(jobname)
        message = (
            f"🗑️ **Job Deleted!**\n\n"
            f"The Jenkins job **{jobname}** has been successfully deleted.\n\n"
            f"🔍 Do you want to create a new job, or perhaps build or manage an existing one?"
        )
        return generate_response(
            intent,
            slots,
            message,
            buttons=[
                {"text": "Create New Job", "value": "Create New Job"},
                {"text": "Build Job", "value": "Build Job"},
                *get_default_buttons()
            ],
            state='Fulfilled'
        )
    except Exception as e:
        return error_response(
            intent,
            slots,
            f"❌ **Deletion Failed**\n\n"
            f"Could not delete the job **{jobname}**. It might not exist or an error occurred.\n\n"
            f"Error: {str(e)}. Please check the job name and try again."
        )
