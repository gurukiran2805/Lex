# job_actions/rename_job_handler.py
from utils.jenkins_connection import rename_job
from utils.response_utils import generate_response, error_response, get_default_buttons

def rename_job_handler(event):
    """
    Handles the 'Rename Job' intent.
    """
    slots = event['sessionState']['intent']['slots']
    intent = event['sessionState']['intent']['name']
    
    old_jobname = slots['JobName']['value']['originalValue']
    new_jobname = slots['NewJobName']['value']['originalValue']
    
    try:
        result = rename_job(old_jobname, new_jobname)
        message = (
            f"✂️ **Job Renamed!**\n\n"
            f"The Jenkins job **{old_jobname}** has been successfully renamed to **{new_jobname}**.\n\n"
            f"🔗 You can access the renamed job here: [New Job URL]({JENKINS_Url}job/{new_jobname}).\n\n"
            f"Would you like to take further action?"
        )
        return generate_response(
            intent,
            slots,
            message,
            buttons=[
                {"text": "Create New Job", "value": "Create New Job"},
                {"text": "Build Job", "value": "Build Job"},
                {"text": "Delete Job", "value": "Delete Job"},
                *get_default_buttons()
            ],
            state='Fulfilled'
        )
    except Exception as e:
        return error_response(
            intent,
            slots,
            f"❌ **Rename Failed**\n\n"
            f"Could not rename the job **{old_jobname}**. It might not exist or an error occurred.\n\n"
            f"Error: {str(e)}. Please check the job name and try again."
        )
