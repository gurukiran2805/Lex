def generate_response(intent, slots, message, state='Fulfilled'):
    """
    Generate a consistent response structure with message.
    """
    return {
        "sessionState": {
            "dialogAction": {
                "type": "Close"
            },
            "intent": {
                'name': intent,
                'slots': slots,
                'state': state
            }
        },
        "messages": [
            {
                "contentType": "PlainText",
                "content": message
            }
        ]
    }

def error_response(intent, slots, error_message):
    """
    Handles error responses in a consistent manner.
    """
    return generate_response(
        intent,
        slots,
        f"❌ **Something went wrong**:\n\n{error_message}\n\nPlease try again later or contact support.",
        state='Failed'
    )

def elicit_slot_response(intent, slots, violated_slot, validation_result):
    """
    Helper function to generate a response for eliciting a slot value during validation failure.

    Parameters:
    - intent (str): The name of the intent being handled.
    - slots (dict): The slots from the current session.
    - violated_slot (str): The name of the violated slot to elicit from the user.
    - message (str, optional): A custom message to display to the user. If not provided, it will not be included in the response.

    Returns:
    - dict: A response structure for eliciting a slot from the user.
    """
    if 'message' in validation_result:
        response = {
            "sessionState": {
                "dialogAction": {
                    'slotToElicit': validation_result['violatedSlot'],
                    "type": "ElicitSlot"
                },
                "intent": {
                    'name': intent,
                    'slots': slots
                }
            },
            "messages": [
                {
                    "contentType": "PlainText",
                    "content": validation_result['message']
                }
            ]
        }
    else:
        response = {
            "sessionState": {
                "dialogAction": {
                    'slotToElicit': validation_result['violatedSlot'],
                    "type": "ElicitSlot"
                },
                "intent": {
                    'name': intent,
                    'slots': slots
                }
            }
        }
    
    return response
