# job_actions/build_job_handler.py
from utils.jenkins_connection import build_job
from utils.response_utils import generate_response, error_response, get_default_buttons

def build_job_handler(event):
    """
    Handles the 'Build Job' intent.
    """
    slots = event['sessionState']['intent']['slots']
    intent = event['sessionState']['intent']['name']
    jobname = slots['JobName']['value']['originalValue']
    
    try:
        build_url = build_job(jobname)
        message = (
            f"🚀 **Build triggered!**\n\n"
            f"The build for job **{jobname}** has started successfully.\n\n"
            f"🔗 You can track the progress and see results here: [Build Status]({build_url})\n\n"
            f"Would you like to do anything else with this job?"
        )
        return generate_response(
            intent,
            slots,
            message,
            buttons=[
                {"text": "Check Build Status", "value": "Check Build Status"},
                {"text": "Build Another Job", "value": "Build Another Job"},
                {"text": "Delete Job", "value": "Delete Job"},
                *get_default_buttons()
            ],
            state='Fulfilled'
        )
    except Exception as e:
        return error_response(
            intent,
            slots,
            f"❌ **Build Failed**\n\n"
            f"Sorry, there was an error while triggering the build for **{jobname}**.\n\n"
            f"Error: {str(e)}. Please check the job name or try again later."
        )
