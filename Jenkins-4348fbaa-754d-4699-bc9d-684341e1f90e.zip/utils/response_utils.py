# utils/response_utils.py

def generate_response(intent, slots, message, buttons, state='Fulfilled'):
    """
    Generate a consistent response structure with message and buttons.
    """
    return {
        "sessionState": {
            "dialogAction": {
                "type": "Close"
            },
            "intent": {
                'name': intent,
                'slots': slots,
                'state': state
            }
        },
        "messages": [
            {
                "contentType": "PlainText",
                "content": message
            }
        ],
        "buttonResponse": {
            "type": "Button",
            "buttons": buttons
        }
    }

def get_default_buttons():
    """
    Returns a set of default buttons that can be reused.
    """
    return [
        {"text": "Create New Job", "value": "Create New Job"},
        {"text": "Build Job", "value": "Build Job"},
        {"text": "Delete Job", "value": "Delete Job"}
    ]

def error_response(intent, slots, error_message):
    """
    Handles error responses in a consistent manner.
    """
    return generate_response(
        intent,
        slots,
        f"❌ **Something went wrong**:\n\n{error_message}\n\nPlease try again later or contact support.",
        buttons=get_default_buttons(),
        state='Failed'
    )
