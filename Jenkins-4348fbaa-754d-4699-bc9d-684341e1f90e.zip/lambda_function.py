from job_actions.create_job_handler import create_job_handler
from job_actions.build_job_handler import build_job_handler
from job_actions.delete_job_handler import delete_job_handler
from job_actions.rename_job_handler import rename_job_handler 
from job_actions.greet_job_handler import greet_job_handler  # Import the new greet handler
from utils.response_utils import error_response

def lambda_handler(event, context):
    """
    AWS Lambda entry point, handles the incoming events from Lex and routes them
    to the correct handler based on the intent.
    """
    print(f"Received event: {event}")
    
    intent = event['sessionState']['intent']['name']
    
    if intent == 'CreateJobIntent':
        return create_job_handler(event)
    elif intent == 'BuildJobIntent':
        return build_job_handler(event)
    elif intent == 'DeleteJobIntent':
        return delete_job_handler(event)
    elif intent == 'RenameJobIntent':  
        return rename_job_handler(event)
    elif intent == 'GreetJobIntent':  
        return greet_job_handler(event)
    else:
        return error_response(
            intent,
            event['sessionState']['intent']['slots'],
            "❌ Sorry, I couldn't process that request. Please try again later."
        )
